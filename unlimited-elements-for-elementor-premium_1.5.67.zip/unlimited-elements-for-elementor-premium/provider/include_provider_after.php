<?php

$pathProvider = dirname(__FILE__)."/";

HelperProviderUC::registerPlugins();
